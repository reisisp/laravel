<header>
    <p>Header with logo</p>
    <hr>
</header>

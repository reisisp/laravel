<form action="">
    <p>
        <input name="login" placeholder='Введите логин'>
        <input type="password" name="pass" placeholder='Введите пароль'>
    </p>
    <input type="checkbox" id="remember" name="remember" value="remember">
    <label for="remember">Remember me</label><br>
    <p><input type="submit"></p>
    <hr>
</form>

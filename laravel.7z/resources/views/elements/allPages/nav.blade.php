<nav>
    <a href='{{route('home')}}'>Главная</a>
    <a href='{{route('news::categories')}}'>Новости</a>
    <a href='{{route('contacts')}}'>Контакты</a>
    <a href='{{route('admin::news::index')}}'>Админка</a>
</nav>

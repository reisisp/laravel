<footer>
    <hr>
    <p>Footer with logo</p>
</footer>
